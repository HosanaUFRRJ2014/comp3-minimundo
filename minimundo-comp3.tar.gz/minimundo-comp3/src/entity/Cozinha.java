package entity;

public class Cozinha extends Comodo {

}
