package entity;

import java.util.LinkedList;

public class Mobilia 
{
	private String descricao;
	private float custoProducao;
	private int tempoEntrega; //num semanas
	
	private LinkedList<Comodo> comodosAssociados = new LinkedList<Comodo>();
	
	public boolean associarComodos(Comodo comodo)
	{
		return comodosAssociados.add(comodo);
		
	}
}
