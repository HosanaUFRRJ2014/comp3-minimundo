package entity;

public class ItemVenda 
{
	private int quantidade;

}
