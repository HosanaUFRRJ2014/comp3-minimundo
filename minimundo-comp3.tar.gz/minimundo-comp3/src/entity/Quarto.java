package entity;

public class Quarto extends Comodo {

}
