package entity;

import java.util.LinkedList;

public abstract class Comodo 
{
	private String descricao;
	private LinkedList<Mobilia> mobiliaDisponivel = new LinkedList<Mobilia>(); 
	
	
	public LinkedList<Mobilia> listaMobiliaDisponivel()
	{
		
		return mobiliaDisponivel;	
	}
	

}
