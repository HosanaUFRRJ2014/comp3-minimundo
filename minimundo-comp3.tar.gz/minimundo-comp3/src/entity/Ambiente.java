package entity;

public class Ambiente 
{
	private int numParedes;
	private int numPortas;
	private float metragem;
	
	public float calcularCusto()
	{
		
	}

	public int calcularTempoIntrega()
	{
		
	}
}
