package entity;

public class Contrato 
{
	private float valorComissao;
	private float valorContrato;
	
	
	public float calcularValorContrato()
	{
		return valorContrato;
	}
	
	public int calcularPrazo()
	{
		return 0; //mudar isso
	}
	

}

//controladores para: ambiente, contrato (alterar, remover, criar), cozinha, sala, quarto, comodoComposto
//um controlador para cada uma dessas coisas. Classes servlets