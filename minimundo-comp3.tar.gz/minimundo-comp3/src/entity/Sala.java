package entity;

public class Sala extends Comodo {

}
