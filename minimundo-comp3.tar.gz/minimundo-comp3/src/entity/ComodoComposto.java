package entity;

public class ComodoComposto extends Comodo {

}
